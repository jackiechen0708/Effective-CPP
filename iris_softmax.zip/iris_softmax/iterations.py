import numpy as np

X = []
y = []
with open("iris.txt") as fp:
    for l in fp.readlines():
        l = l.replace("\n", "").split(",")
        X.append([float(i) for i in l[:-1]])
        y.append(int(l[-1]) - 1)

print(X)
print(y)

X = np.array(X)
y = np.array(y)
X = X - np.mean(X, axis=0)

X = X / np.linalg.norm(X, axis=1).reshape(150, 1)

W = np.random.random((3, 4))
lmd = 0.01


# print(W)
def f(X, W, y):
    # print(W[:, y].T.reshape(150,5,1))
    # print((np.tile(W,(150,1,1))))
    # W_ = (np.tile(W, (X.shape[0], 1, 1)) - W[:, y].T.reshape(X.shape[0], 5, 1))
    # print(W_.shape)
    # print(X.shape)
    # return np.sum(np.exp(X@(W - W[y]))) + lmd / 2 * W ** 2
    result = lmd / 2 * np.sum(W ** 2)
    for i in range(X.shape[0]):
        # result += np.log(np.sum(np.exp(X[i] @ W_[i])))
        # print("W-W[y[i]]", W - W[y[i]])
        # print("forward",np.exp(X[i] @ (W - W[y[i]]).T))
        result += np.log(np.sum(np.exp(X[i] @ (W - W[y[i]]).T)))
    return result


# print(f(X, W, y))


def df(X, W, y):
    # W_ = (np.tile(W, (X.shape[0], 1, 1)) - W[:, y].T.reshape(X.shape[0], 5, 1))
    dw = lmd * W
    for i in range(X.shape[0]):
        # print ("low",np.exp(X[i] @ (W - W[y[i]]).T))
        tmp = np.sum(np.exp(X[i] @ (W - W[y[i]]).T))
        # print ("X[i]",X[i])
        # print(y[i])
        # print ((W - W[y[i]]).T)
        # print ('r',np.exp(X[i] @ (W - W[y[i]]).T))
        # print("W", np.exp(X[i] @ (W - W[y[i]]).T))
        # print("result",(X[i].reshape(-1,1) @ np.exp(X[i] @ (W - W[y[i]]).T).reshape(1,-1)).T)
        # print ("result",(X[i].reshape(-1,1) @ np.exp(X[i] @ (W - W[y[i]]).T).reshape(1,-1)).T)
        dw -= (X[i].reshape(-1, 1) @ np.exp(X[i] @ (W - W[y[i]]).T).reshape(1, -1)).T / tmp
    return dw


def predict(X, W):
    # print(X @ (W).T)
    return np.argmax(X @ (W).T, axis=1)


all_iters = 0
for i in range(100):
    # randomly choose trainning set and test set
    from random import shuffle

    index = [i for i in range(X.shape[0])]
    shuffle(index)

    X = X[index, :]

    y = y[index]
    Xtrain = X[:120]
    Xtest = X[120:]

    ytrain = y[:120]
    ytest = y[120:]

    print(Xtrain.shape)
    print(ytrain.shape)

    iters = 0  # iteration counter
    while (True):
        # print(W)
        # print(iters, f(Xtrain, W, ytrain))
        pred = predict(Xtrain, W)
        acc = np.sum(pred == ytrain) / ytrain.shape[0]
        # print(acc)

        dw = df(Xtrain, W, ytrain)
        # print(np.sum(dw ** 2) / (1 + f(Xtrain, W, ytrain)))
        if(np.sum(dw ** 2) / (1 + f(Xtrain, W, ytrain)) < 1e-6):
            break
        W -= 1e-5 * dw;
        iters += 1
    all_iters += iters

print("Average w is : ", all_iters / 100)
