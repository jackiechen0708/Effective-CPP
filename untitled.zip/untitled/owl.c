#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graph.h"

// Constants
#define MAX_WORD_NUM 1000
#define MAX_WORD_LEN 20

// Global Variables
int num_of_words;
char words[MAX_WORD_NUM][MAX_WORD_LEN];
Graph graph;

// differ by one function
bool differByOne(char *str1, char *str2) {
    int len1 = strlen(str1);
    int len2 = strlen(str2);
    int diff_num = 0;
    if (len1 == len2) {
        for (int i = 0; i < len1; i++) {
            if (str1[i] != str2[i])
                diff_num++;
        }
        return diff_num == 1;
    } else {
        int i = 0, j = 0;
        if (len1 == len2 + 1) {
            while (j < len2) {
                if (str1[i] != str2[j]) {
                    if (diff_num == 0) {
                        i++;
                        diff_num += 1;
                    } else {
                        return false;
                    }
                } else {
                    i++;
                    j++;
                }
            }
            return (diff_num == 0 || i == j + 1);
        } else if (len2 == len1 + 1) {
            while (i < len1) {
                if (str1[i] != str2[j]) {
                    if (diff_num == 0) {
                        j++;
                        diff_num += 1;
                    } else {
                        return false;
                    }
                } else {
                    i++;
                    j++;
                }
            }
            return (diff_num == 0 || i + 1 == j);
        } else {
            return false;
        }
    }
}

// read words
void readWords() {
    num_of_words = 0;
    while (scanf("%s", words[num_of_words++]));
}

// construct graph
void construct_graph() {
    graph = newGraph(num_of_words);
    for (int i = 0; i < num_of_words; i++) {
        for (int j = i + 1; j < num_of_words; j++) {
            if (differByOne(words[i],words[j])){
                insertEdge(newEdge(i,j),graph);
            }
        }
    }
}

// print the result
void printResult() {
    printf("Dictionary\n");
    for (int i = 0; i < num_of_words; i++) {
        printf("%d: %s\n", i, words[i]);
    }
    printf("Ordered Word Ladder Graph\n");
    showGraph(graph);
}

int main() {

    readWords();
    construct_graph();
    printResult();


    printf("%d\n", differByOne("bce", "abcd"));
}