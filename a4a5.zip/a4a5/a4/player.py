import math


class BasePlayer:
    def __init__(self, depthLimit):
        self.depthLimit = depthLimit


    # Assign integer scores to the three terminal states
    # P2_WIN_SCORE < DRAW_SCORE < P1_WIN_SCORE
    # Access these with "self.DRAW_SCORE", etc.
    P1_WIN_SCORE = 1000000
    P2_WIN_SCORE = -P1_WIN_SCORE
    DRAW_SCORE = 0

    # Returns a heuristic for the board position
    # Good positions for 0 pieces should be positive and
    # good positions for 1 pieces should be negative
    # for all boards, P2_WIN_SCORE < heuristic(b) < P1_WIN_SCORE
    # TODO: here change
    def heuristic(self, board):
        row_3 = [0, 0]
        row_2 = [0, 0]
        for c in range(len(board.board)):
            for r in range(len(board.board[c])):
                pos = board.board[c][r]
                # horizontal case
                try:
                    n1 = board.board[c + 1][r]
                except:
                    n1 = -1
                try:
                    n2 = board.board[c + 2][r]
                except:
                    n2 = -1
                try:
                    n3 = board.board[c + 3][r]
                except:
                    n3 = -1
                # Three in a r
                if ((pos == n1 and pos == n2 and n3 == -1) or
                        (pos == n1 and pos == n3 and n2 == -1) or
                        (pos == n2 and pos == n3 and n1 == -1)):
                    row_3[pos] += 1
                    row_2[pos] -= 1
                # Two in a r
                elif ((pos == n1 and n2 == -1) or
                      (pos == n2 and n1 == -1) or
                      (pos == n3 and n1 == -1 and n2 == -1)):
                    row_2[pos] += 1

                # Vertical checks
                try:
                    n1 = board.board[c][r + 1]
                except:
                    n1 = -1
                try:
                    n2 = board.board[c][r + 2]
                except:
                    n2 = -1
                try:
                    n3 = board.board[c][r + 3]
                except:
                    n3 = -1

                # Three in a r
                if ((pos == n1 and pos == n2 and n3 == -1) or
                        (pos == n1 and pos == n3 and n2 == -1) or
                        (pos == n2 and pos == n3 and n1 == -1)):
                    row_3[pos] += 1
                    row_2[pos] -= 1
                # Two in a r
                elif ((pos == n1 and n2 == -1) or
                      (pos == n2 and n1 == -1) or
                      (pos == n3 and n1 == -1 and n2 == -1)):
                    row_2[pos] += 1

                try:
                    n1 = board.board[c + 1][r + 1]
                except:
                    n1 = -1
                try:
                    n2 = board.board[c + 2][r + 2]
                except:
                    n2 = -1
                try:
                    n3 = board.board[c + 3][r + 3]
                except:
                    n3 = -1

                # Three in a r
                if ((pos == n1 and pos == n2 and n3 == -1) or
                        (pos == n1 and pos == n3 and n2 == -1) or
                        (pos == n2 and pos == n3 and n1 == -1)):
                    row_3[pos] += 1
                    row_2[pos] -= 1
                # Two in a r
                elif ((pos == n1 and n2 == -1) or
                      (pos == n2 and n1 == -1) or
                      (pos == n3 and n1 == -1 and n2 == -1)):
                    row_2[pos] += 1

                try:
                    n1 = board.board[c + 1][r - 1]
                except:
                    n1 = -1
                try:
                    n2 = board.board[c + 2][r - 2]
                except:
                    n2 = -1
                try:
                    n3 = board.board[c + 3][r - 3]
                except:
                    n3 = -1

                # Three in a r
                if ((pos == n1 and pos == n2 and n3 == -1) or
                        (pos == n1 and pos == n3 and n2 == -1) or
                        (pos == n2 and pos == n3 and n1 == -1)):
                    row_3[pos] += 1
                    row_2[pos] -= 1
                    # Two in a r
                elif ((pos == n1 and n2 == -1) or
                      (pos == n2 and n1 == -1) or
                      (pos == n3 and n1 == -1 and n2 == -1)):
                    row_2[pos] += 1

        return (row_3[0] * 10 + row_2[0]) - (row_3[1] * 10 + row_2[1])


class ManualPlayer(BasePlayer):
    def __init__(self, depthLimit=None):
        BasePlayer.__init__(self, depthLimit)

    def findMove(self, board):
        opts = " "
        for c in range(board.WIDTH):
            opts += " " + (str(c + 1) if len(board.board[c]) < board.HEIGHT else ' ') + "  "
        print(opts)

        while True:
            col = input("Place a " + ('O' if board.turn == 0 else 'X') + " in column: ")
            try:
                col = int(col) - 1
            except ValueError:
                continue
            if col >= 0 and col < board.WIDTH and len(board.board[col]) < board.HEIGHT:
                return col


class PlayerMM(BasePlayer):
    # performs minimax on board with depth.
    # returns the best move and best score as a tuple
    def minimax(self, board, depth):
        #TODO: here
        term = board.isTerminal()
        if term == -1: return (-1, self.DRAW_SCORE)
        if term == 0: return (-1, self.P1_WIN_SCORE)
        if term == 1: return (-1, self.P2_WIN_SCORE)
        if depth == 0: return (-1, self.heuristic(board))
        if board.turn == 0:
            bestmove = (None, -math.inf)
            for i in board.getValidMoves():
                child = board.getChild(i)
                move, cost = self.minimax(child, depth - 1)
                if cost >= bestmove[1]:
                    bestmove = (i, cost)
        else:
            bestmove = (-1, math.inf)
            for i in board.getValidMoves():
                child = board.getChild(i)
                move, cost = self.minimax(child, depth - 1)
                if cost <= bestmove[1]:
                    bestmove = (i, cost)
        return bestmove

    def findMove(self, board):
        move, score = self.minimax(board, self.depthLimit)
        return move


class PlayerAB(BasePlayer):
    # performs minimax on board with depth.
    # alpha represents the score of max's current strategy
    # beta  represents the score of min's current strategy
    # in a cutoff situation, return the score that resulted in the cutoff
    # returns the best move and best score as a tuple
    def minimax_ab(self, board, depth, alpha, beta):
        # TODO: here change
        term = board.isTerminal()
        if term == -1: return (-1, self.DRAW_SCORE)
        if term == 0: return (-1, self.P1_WIN_SCORE)
        if term == 1: return (-1, self.P2_WIN_SCORE)
        if depth == 0: return (-1, self.heuristic(board))
        if board.turn == 0:
            bestmove = (None, -math.inf)
            validMoves = board.getValidMoves()
            for i in validMoves:
                move, cost = self.minimax_ab(board.getChild(i), depth - 1, alpha, beta)
                if cost >= bestmove[1]:
                    bestmove = (i, cost)
                alpha = max(alpha, bestmove[1])
                if alpha >= beta:
                    break
            return bestmove
        else:
            bestmove = (-1, math.inf)
            validMoves = board.getValidMoves()
            for i in validMoves:
                move, cost = self.minimax_ab(board.getChild(i), depth - 1, alpha, beta)
                if cost <= bestmove[1]:
                    bestmove = (i, cost)
                beta = min(beta, bestmove[1])
                if alpha >= beta:
                    break
            return bestmove

    def findMove(self, board):
        move, score = self.minimax_ab(board, self.depthLimit, -math.inf, math.inf)
        return move


class PlayerDP(PlayerAB):
    ''' A version of PlayerAB that implements dynamic programming
        to cache values for its heuristic function, improving performance. '''

    def __init__(self, depthLimit):
        PlayerAB.__init__(self, depthLimit)

        self.resolved = {}

    # if a saved heuristic value exists in self.resolved for board.state, returns that value
    # otherwise, uses BasePlayer.heuristic to get a heuristic value and saves it under board.state
    def heuristic(self, board):
        # TODO: here change
        if board.state in self.resolved.keys():
            return self.resolved[board.state]
        else:
            h = super().heuristic(board)
            self.resolved[board.state] = h
            return h


#######################################################
###########Example Subclass for Testing
#######################################################

# This will inherit your findMove from above, but will override the heuristic function with
# a new one; you can swap out the type of player by changing X in "class TestPlayer(X):"
class TestPlayer(BasePlayer):
    # define your new heuristic here
    def heurisitic(self):
        pass
